SMODS.Joker{ --Smokey Bears
    key = "smokeybears",
    config = {
        extra = {
        }
    },
    loc_txt = {
        ['name'] = 'Smokey Bears',
        ['text'] = {
            [1] = 'When hand is played, makes first scored card {C:legendary}Negative{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 2,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 3,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if context.other_card == context.scoring_hand[1] then
                context.other_card:set_edition("e_negative", true)
                return {
                    message = "Card Modified!"
                }
            end
        end
    end
}