SMODS.Joker{ --Lithe Nation
    key = "lithenation",
    config = {
        extra = {
        }
    },
    loc_txt = {
        ['name'] = 'Lithe Nation',
        ['text'] = {
            [1] = 'All played face cards become {C:dark_edition} FADED {} cards when scored'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 0,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if context.other_card:is_face() then
                context.other_card:set_ability(G.P_CENTERS.m_corvo_faded)
                return {
                    message = "Card Modified!"
                }
            end
        end
    end
}