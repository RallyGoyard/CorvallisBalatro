SMODS.Joker{ --Young Saya
    key = "youngsaya",
    config = {
        extra = {
            sayastruck = 5
        }
    },
    loc_txt = {
        ['name'] = 'Young Saya',
        ['text'] = {
            [1] = 'All played cards become {C:orange}Gold Aces{} with {C:attention}Gold Seals{} when scored.',
            [2] = 'After 5 hands, Young Saya self destructs when the next blind is selected'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 0,
        y = 2
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 3,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
                assert(SMODS.change_base(context.other_card, nil, "Ace"))
                context.other_card:set_ability(G.P_CENTERS.m_gold)
                context.other_card:set_seal("Gold", true)
                return {
                    message = "Card Modified!"
                }
        end
        if context.cardarea == G.jokers and context.joker_main  then
                card.ability.extra.sayastruck = math.max(0, (card.ability.extra.sayastruck) - 1)
        end
        if context.setting_blind  then
            if (card.ability.extra.sayastruck or 0) == 0 then
                return {
                    func = function()
                card:start_dissolve()
                return true
            end,
                    message = "Destroyed!"
                }
            end
        end
    end
}