SMODS.Joker{ --Hurricane
    key = "hurricane",
    config = {
        extra = {
            discardsremaining = 0
        }
    },
    loc_txt = {
        ['name'] = 'Hurricane',
        ['text'] = {
            [1] = 'Gives {X:mult,C:white}x1{} Mult per remaining {C:red}discard{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 7,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 2,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
                return {
                    Xmult = G.GAME.current_round.discards_left
                }
        end
    end
}