SMODS.Joker{ --Jakey
    key = "jakey",
    config = {
        extra = {
            rounds = 0,
            dollars = 500
        }
    },
    loc_txt = {
        ['name'] = 'Jakey',
        ['text'] = {
            [1] = 'After {C:attention}5{} rounds, sell this card to gain {C:gold}$200{} {C:attention}',
            [2] = '{C:inactive}(Currently {C:attention}#1#{}/5){}',
            [3] = ''
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 8,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.rounds}}
    end,

    calculate = function(self, card, context)
        if context.selling_card  then
            if (card.ability.extra.rounds or 0) >= 5 then
                return {
                    dollars = card.ability.extra.dollars
                }
            end
        end
        if context.end_of_round and context.game_over == false and context.main_eval  then
                return {
                    func = function()
                    card.ability.extra.rounds = (card.ability.extra.rounds) + 1
                    return true
                end
                }
        end
    end
}