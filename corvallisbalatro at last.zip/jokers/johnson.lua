SMODS.Joker{ --Johnson
    key = "johnson",
    config = {
        extra = {
            chipsvar = 0
        }
    },
    loc_txt = {
        ['name'] = 'Johnson',
        ['text'] = {
            [1] = 'Gains {C:chips}+50{} Chips if played hand contains a {C:orange}flush{}',
            [2] = '{C:inactive}(Currently {C:blue}+#1#{} Chips){}'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 9,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 3,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    loc_vars = function(self, info_queue, card)
        return {vars = {card.ability.extra.chipsvar}}
    end,

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
            if next(context.poker_hands["Flush"]) then
                card.ability.extra.chipsvar = (card.ability.extra.chipsvar) + 50
                return {
                    chips = card.ability.extra.chipsvar
                }
            else
                return {
                    chips = card.ability.extra.chipsvar
                }
            end
        end
    end
}