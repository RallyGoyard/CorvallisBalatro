SMODS.Joker{ --FloatingMessMaya
    key = "floatingmessmaya",
    config = {
        extra = {
            cardsdiscarded = 23,
            xmultvar = 1
        }
    },
    loc_txt = {
        ['name'] = 'FloatingMessMaya',
        ['text'] = {
            [1] = 'Gains {X:blue,C,C:white}X1{} Chip Mult every {C:orange}23{} cards discarded',
            [2] = ''
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 3,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 6,
    rarity = 3,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.discard  then
                return {
                    func = function()
                    card.ability.extra.cardsdiscarded = math.max(0, (card.ability.extra.cardsdiscarded) - 1)
                    return true
                end
                }
        end
        if context.pre_discard  then
            if (card.ability.extra.cardsdiscarded or 0) == 0 then
                return {
                    func = function()
                    card.ability.extra.cardsdiscarded = 23
                    return true
                end,
                    extra = {
                        func = function()
                    card.ability.extra.xmultvar = (card.ability.extra.xmultvar) + 1
                    return true
                end,
                        colour = G.C.GREEN
                        }
                }
            end
        end
        if context.cardarea == G.jokers and context.joker_main  then
                return {
                    x_chips = card.ability.extra.xmultvar
                }
        end
    end
}