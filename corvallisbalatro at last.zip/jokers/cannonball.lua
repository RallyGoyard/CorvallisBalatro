SMODS.Joker{ --Cannonball
    key = "cannonball",
    config = {
        extra = {
            hand_size = 1,
            hands = 2,
            round = 0
        }
    },
    loc_txt = {
        ['name'] = 'Cannonball',
        ['text'] = {
            [1] = '{C:blue}-2 hands{}',
            [2] = '{C:attention}+1{} hand size every time blind is selected'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 2,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.setting_blind  then
                return {
                    func = function()
                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "+"..tostring(card.ability.extra.hand_size).." Hand Size", colour = G.C.BLUE})
                G.hand:change_size(card.ability.extra.hand_size)
                return true
            end
                }
        end
        if context.first_hand_drawn  then
                return {
                    func = function()
                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "-"..tostring(card.ability.extra.hands).." Hand", colour = G.C.RED})
                G.GAME.current_round.hands_left = G.GAME.current_round.hands_left - card.ability.extra.hands
                return true
            end
                }
        end
    end
}