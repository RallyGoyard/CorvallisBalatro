SMODS.Joker{ --Tomfoolery
    key = "tomfoolery",
    config = {
        extra = {
            pb_mult_546bed6e = 2,
            perma_mult = 0
        }
    },
    loc_txt = {
        ['name'] = 'Tomfoolery',
        ['text'] = {
            [1] = 'Every played {C:attention}card{} permanently',
            [2] = 'gains {C:red}+2{} Mult when scored'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 7,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
                context.other_card.ability.perma_mult = context.other_card.ability.perma_mult or 0
                context.other_card.ability.perma_mult = context.other_card.ability.perma_mult + card.ability.extra.pb_mult_546bed6e
                return {
                    extra = { message = localize('k_upgrade_ex'), colour = G.C.MULT }, card = card
                }
        end
    end
}