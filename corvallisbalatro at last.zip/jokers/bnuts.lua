SMODS.Joker{ --BNUTS
    key = "bnuts",
    config = {
        extra = {
            Xmult = 100,
            dollars = 0,
            odds = 10,
            yes = 0,
            var1 = 0
        }
    },
    loc_txt = {
        ['name'] = 'BNUTS',
        ['text'] = {
            [1] = '{X:red,C:white}X100{} Mult',
            [2] = 'Destroys a random joker each hand',
            [3] = 'Sets money to $0 each hand drawn',
            [4] = 'Bypasses eternals',
            [5] = '{C:green}1{} in {C:uncommon}10{} chance to self destruct'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 0,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.cardarea == G.jokers and context.joker_main  then
                return {
                    Xmult = card.ability.extra.Xmult,
                    message = "FLORIDA CHOP"
                }
        end
        if context.hand_drawn  then
                return {
                    func = function()
                    local target_amount = card.ability.extra.dollars
                    local current_amount = G.GAME.dollars
                    local difference = target_amount - current_amount
                    ease_dollars(difference)
                    card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "broke", colour = G.C.MONEY})
                    return true
                end
                }
        end
        if context.before and context.cardarea == G.jokers  then
                return {
                    func = function()
                local destructable_jokers = {}
                for i, joker in ipairs(G.jokers.cards) do
                    if joker ~= card and not joker.getting_sliced then
                        table.insert(destructable_jokers, joker)
                    end
                end
                local target_joker = #destructable_jokers > 0 and pseudorandom_element(destructable_jokers, pseudoseed('destroy_joker')) or nil
                
                if target_joker then
                    if target_joker.ability.eternal then
                        target_joker.ability.eternal = nil
                    end
                    target_joker.getting_sliced = true
                    G.E_MANAGER:add_event(Event({
                        func = function()
                            target_joker:start_dissolve({G.C.RED}, nil, 1.6)
                            return true
                        end
                    }))
                    card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "Destroyed!", colour = G.C.RED})
                end
                    return true
                end
                }
        end
        if context.end_of_round and context.game_over == false and context.main_eval  then
            if true then
                if SMODS.pseudorandom_probability(card, 'group_0_cda7de35', 1, card.ability.extra.odds, 'j_corvo_bnuts', false) then
              SMODS.calculate_effect({func = function()
                card:start_dissolve()
                return true
            end}, card)
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "DEAD!", colour = G.C.RED})
          end
            end
        end
    end
}