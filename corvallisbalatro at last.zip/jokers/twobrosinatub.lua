SMODS.Joker{ --Two bros in a tub
    key = "twobrosinatub",
    config = {
        extra = {
            Tarot = 0
        }
    },
    loc_txt = {
        ['name'] = 'Two bros in a tub',
        ['text'] = {
            [1] = 'If {C:attention}first hand{} of round is a {C:attention}pair{},',
            [2] = 'add a negative {C:tarot}Tarot{} per scored card'
        },
        ['unlock'] = {
            [1] = ''
        }
    },
    pos = {
        x = 8,
        y = 1
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 3,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if (G.GAME.current_round.hands_played == 0 and context.scoring_name == "Pair") then
                local created_consumable = true
                G.E_MANAGER:add_event(Event({
                    func = function()
                        SMODS.add_card{set = 'Tarot', key = nil, edition = 'e_negative', key_append = 'joker_forge_tarot'}
                        return true
                    end
                }))
                return {
                    message = created_consumable and localize('k_plus_tarot') or nil
                }
            end
        end
    end
}