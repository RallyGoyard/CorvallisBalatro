SMODS.Joker{ --Home
    key = "home",
    config = {
        extra = {
        }
    },
    loc_txt = {
        ['name'] = 'Home',
        ['text'] = {
            [1] = 'Redeems a random voucher when boss blind is defeated'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 6,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 4,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',

    calculate = function(self, card, context)
        if context.end_of_round and context.main_eval and G.GAME.blind.boss  then
                local voucher_key = pseudorandom_element(G.P_CENTER_POOLS.Voucher, "13cfb36e").key
    local voucher_card = SMODS.create_card{area = G.play, key = voucher_key}
    voucher_card:start_materialize()
    voucher_card.cost = 0
    G.play:emplace(voucher_card)
    delay(0.8)
    voucher_card:redeem()

    G.E_MANAGER:add_event(Event({
        trigger = 'after',
        delay = 0.5,
        func = function()
            voucher_card:start_dissolve()                
            return true
        end
    }))
                return {
                    message = nil
                }
        end
    end
}