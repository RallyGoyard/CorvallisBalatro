SMODS.Consumable {
    key = 'moneymatch',
    set = 'Tarot',
    pos = { x = 1, y = 0 },
    config = { extra = {
        odds = 4,
        odds2 = 15,
        dollars_value = 50,
        dollars_value = 100
    } },
    loc_txt = {
        name = 'Money Match',
        text = {
        [1] = 'When consumed,',
        [2] = '{C:green}1 in 4{} chance to Gain {C:money}$50{}',
        [3] = 'or',
        [4] = '{C:green}1 in 15{} chance to lose {C:money}$100{}',
        [5] = 'Big chance to do nothing at all'
    }
    },
    cost = 3,
    unlocked = true,
    discovered = true,
    hidden = false,
    can_repeat_soul = false,
    atlas = 'CustomConsumables',
    use = function(self, card, area, copier)
        local used_card = copier or card
            G.E_MANAGER:add_event(Event({
                trigger = 'after',
                delay = 0.4,
                func = function()
                    play_sound('timpani')
                    used_card:juice_up(0.3, 0.5)
                    card_eval_status_text(used_card, 'extra', nil, nil, nil, {message = "OK", colour = G.C.BLUE})
                    G.GAME.pool_flags.corvo_custom_flag = true
                    return true
                end
            }))
            delay(0.6)
            if SMODS.pseudorandom_probability(card, 'group_0_fefcd655', 1, card.ability.extra.odds, 'c_corvo_moneymatch', false) then
                
                G.E_MANAGER:add_event(Event({
                trigger = 'after',
                delay = 0.4,
                func = function()
                    card_eval_status_text(used_card, 'extra', nil, nil, nil, {message = "+"..tostring(50).." $", colour = G.C.MONEY})
                    ease_dollars(50, true)
                    return true
                end
            }))
            delay(0.6)
                G.E_MANAGER:add_event(Event({
                trigger = 'after',
                delay = 0.4,
                func = function()
                    play_sound('timpani')
                    used_card:juice_up(0.3, 0.5)
                    card_eval_status_text(used_card, 'extra', nil, nil, nil, {message = "GG EZ", colour = G.C.BLUE})
                    G.GAME.pool_flags.corvo_custom_flag = true
                    return true
                end
            }))
            delay(0.6)
            end
            if SMODS.pseudorandom_probability(card, 'group_1_dbfd6136', 1, card.ability.extra.odds2, 'c_corvo_moneymatch', false) then
                
                G.E_MANAGER:add_event(Event({
                trigger = 'after',
                delay = 0.4,
                func = function()
                    card_eval_status_text(used_card, 'extra', nil, nil, nil, {message = "-"..tostring(100).." $", colour = G.C.RED})
                    ease_dollars(-math.min(G.GAME.dollars, 100), true)
                    return true
                end
            }))
            delay(0.6)
                G.E_MANAGER:add_event(Event({
                trigger = 'after',
                delay = 0.4,
                func = function()
                    play_sound('timpani')
                    used_card:juice_up(0.3, 0.5)
                    card_eval_status_text(used_card, 'extra', nil, nil, nil, {message = "UR ASS KID", colour = G.C.BLUE})
                    G.GAME.pool_flags.corvo_custom_flag = true
                    return true
                end
            }))
            delay(0.6)
            end
    end,
    can_use = function(self, card)
        return true
    end
}