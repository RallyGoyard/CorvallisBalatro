SMODS.Seal {
    key = 'blurpseal',
    pos = { x = 0, y = 0 },
    badge_colour = HEX('FF6B6B'),
   loc_txt = {
        name = 'Blurp Seal',
        label = 'Blurp Seal',
        text = {
        [1] = 'When this card is discarded, destroy it, and create a negative {C:spectral}spectral{} card'
    }
    },
    atlas = 'CustomSeals',
    unlocked = true,
    discovered = true,
    no_collection = false,
    calculate = function(self, card, context)
        if context.discard and context.other_card == card then
            return { func = function()local created_consumable = true
                G.E_MANAGER:add_event(Event({
                    func = function()
                        SMODS.add_card{set = 'Spectral', edition = 'e_negative', key_append = 'enhanced_card_spectral'}
                        return true
                    end
                }))
                    if created_consumable then
                        card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "+1 Consumable!", colour = G.C.SECONDARY_SET.Spectral})
                    end
                    return true
                end, remove = true }
        end
    end
}