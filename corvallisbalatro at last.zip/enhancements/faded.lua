SMODS.Enhancement {
    key = 'faded',
    pos = { x = 0, y = 0 },
    config = {
        extra = {
            x_chips = 2,
            odds = 4
        }
    },
    loc_txt = {
        name = 'FADED',
        text = {
        [1] = '{C:blue}x2 chips{}, {C:red}1 in 4{} chance to self destruct'
    }
    },
    atlas = 'CustomEnhancements',
    any_suit = false,
    shatters = true,
    replace_base_card = false,
    no_rank = false,
    no_suit = false,
    always_scores = false,
    unlocked = true,
    discovered = true,
    no_collection = false,
    weight = 10,
    calculate = function(self, card, context)
        if context.destroy_card and context.cardarea == G.play and context.destroy_card == card and card.should_destroy then
            return { remove = true }
        end
        if context.main_scoring and context.cardarea == G.play then
            card.should_destroy = false
            if SMODS.pseudorandom_probability(card, 'group_0_a7cf6850', 1, card.ability.extra.odds, 'm_corvo_faded', false) then
                card.should_destroy = true
            end
            return { x_chips = card.ability.extra.x_chips }
        end
    end
}